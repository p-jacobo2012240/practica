# Instanlacion #

Al momento de descargar o clonar este repositorio, debe ingresar a la consola, en la ruta del proyecto y utilizar el comando

```
npm install
```

Para poder instalar todas las dependencias del proyecto.
Para ejecutar el proyecto se necesita el comando.

```
npm start
```
